const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState, useEffect, useCallback } from 'react';

export function useCrud(entityName) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await db.entities[entityName].list('-updated_date', 200);
      setItems(data);
    } catch (e) {
      setItems([]);
    } finally {
      setLoading(false);
    }
  }, [entityName]);

  useEffect(() => { load(); }, [load]);

  const save = async (values) => {
    if (editing) {
      await db.entities[entityName].update(editing.id, values);
      setEditing(null);
    } else {
      await db.entities[entityName].create(values);
    }
    await load();
  };

  const remove = async (id) => {
    await db.entities[entityName].delete(id);
    if (editing && editing.id === id) setEditing(null);
    await load();
  };

  const startEdit = (item) => setEditing(item);
  const cancelEdit = () => setEditing(null);

  return { items, loading, editing, save, remove, startEdit, cancelEdit, reload: load };
}