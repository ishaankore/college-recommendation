const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from 'react';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';
import { Link } from 'react-router-dom';
import { Plus, Trash2, School, Sparkles, ChevronRight } from 'lucide-react';
import { collegeStatusStyle } from '@/lib/assessment';
import CollegeSearchInput from '@/components/profile/CollegeSearchInput';
import PageHeader from '@/components/PageHeader';

export default function Colleges() {
  const { toast } = useToast();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({ name: '', notes: '', deadline: '' });

  const load = async () => {
    setLoading(true);
    try {
      setItems(await db.entities.College.list('-updated_date', 200));
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => { load(); }, []);

  const submit = async (e) => {
    e.preventDefault();
    if (!form.name.trim()) return;
    await db.entities.College.create({ ...form, deadline: form.deadline || undefined, status: 'Not rated' });
    setForm({ name: '', notes: '', deadline: '' });
    await load();
  };
  const remove = async (id) => {
    await db.entities.College.delete(id);
    await load();
  };

  const rated = items.filter((c) => c.status && c.status !== 'Not rated').length;

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-10">
      <PageHeader eyebrow="Colleges" icon={School} title="Target colleges" description="Build your list. Run an analysis on the dashboard to rate each one against your profile." />

      <form onSubmit={submit} className="grid grid-cols-1 sm:grid-cols-6 gap-3 items-end bg-muted/40 rounded-xl p-4 mb-6">
        <div className="sm:col-span-3 space-y-1">
          <Label className="text-xs text-muted-foreground">College name</Label>
          <CollegeSearchInput value={form.name} onChange={(name) => setForm((f) => ({ ...f, name }))} />
        </div>
        <div className="sm:col-span-2 space-y-1">
          <Label className="text-xs text-muted-foreground">Notes</Label>
          <Input value={form.notes} onChange={(e) => setForm((f) => ({ ...f, notes: e.target.value }))} placeholder="EA, in-state, engineering" />
        </div>
        <div className="space-y-1">
          <Label className="text-xs text-muted-foreground">Deadline</Label>
          <Input type="date" value={form.deadline} onChange={(e) => setForm((f) => ({ ...f, deadline: e.target.value }))} />
        </div>
        <div className="sm:col-span-6">
          <Button type="submit" size="sm" className="w-full sm:w-auto"><Plus className="w-4 h-4 mr-1" />Add college</Button>
        </div>
      </form>

      {items.length === 0 ? (
        <div className="text-center py-16 rounded-xl border border-dashed">
          <School className="w-8 h-8 mx-auto text-muted-foreground/60" />
          <p className="text-sm text-muted-foreground mt-3">No colleges yet. Add the schools you're considering.</p>
        </div>
      ) : (
        <div className="space-y-2">
          {rated === 0 && (
            <Link to="/" className="flex items-center justify-between gap-3 rounded-xl bg-indigo-50 border border-indigo-100 px-4 py-3 text-sm text-indigo-700 hover:bg-indigo-100 transition-colors mb-2">
              <span className="flex items-center gap-2"><Sparkles className="w-4 h-4" />Run an analysis to rate these colleges against your profile</span>
              <ChevronRight className="w-4 h-4" />
            </Link>
          )}
          {items.map((c) => (
            <div key={c.id} className="flex items-start justify-between gap-3 rounded-lg border px-4 py-3">
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <div className="font-medium truncate">{c.name}</div>
                  <Badge className={collegeStatusStyle(c.status)}>{c.status}</Badge>
                </div>
                {c.notes && <div className="text-sm text-muted-foreground mt-0.5">{c.notes}</div>}
                {c.rationale && <div className="text-xs text-muted-foreground mt-1 italic">{c.rationale}</div>}
                {c.deadline && <div className="text-xs text-muted-foreground mt-1">Deadline: {c.deadline}</div>}
              </div>
              <Button size="icon" variant="ghost" className="shrink-0" onClick={() => remove(c.id)}><Trash2 className="w-4 h-4 text-rose-500" /></Button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}