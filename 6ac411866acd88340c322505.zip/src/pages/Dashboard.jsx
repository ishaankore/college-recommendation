const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from 'react';

import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Link } from 'react-router-dom';
import { tierStyle } from '@/lib/assessment';
import PageHeader from '@/components/PageHeader';
import SectionCard from '@/components/SectionCard';
import moment from 'moment';
import { Sparkles, Target, Ban, TrendingUp, School, ChevronRight, RefreshCw, BookOpen, Award, FileText, User, Lightbulb, Gauge } from 'lucide-react';

const SECTIONS = [
  { key: 'courses', label: 'Courses', icon: BookOpen, to: '/profile' },
  { key: 'tests', label: 'Test scores', icon: TrendingUp, to: '/profile' },
  { key: 'activities', label: 'Activities', icon: User, to: '/profile' },
  { key: 'awards', label: 'Awards', icon: Award, to: '/profile' },
  { key: 'essays', label: 'Essays', icon: FileText, to: '/profile' },
  { key: 'interests', label: 'Interests', icon: Lightbulb, to: '/profile' },
  { key: 'colleges', label: 'Colleges', icon: School, to: '/colleges' },
];

const STEPS = [
  { n: 1, title: 'Build your profile', detail: 'Add courses, activities, awards, essays, test scores, and interests.', to: '/profile', cta: 'Open profile' },
  { n: 2, title: 'Add target colleges', detail: 'List the schools you are considering.', to: '/colleges', cta: 'Add colleges' },
  { n: 3, title: 'Run an analysis', detail: 'Get your standing, monthly priorities, and per-college ratings.', to: '/', cta: 'Analyze' },
];

export default function Dashboard() {
  const { toast } = useToast();
  const [assessment, setAssessment] = useState(null);
  const [counts, setCounts] = useState({});
  const [loading, setLoading] = useState(true);
  const [analyzing, setAnalyzing] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const [assessments, courses, tests, activities, awards, essays, interests, colleges] = await Promise.all([
        db.entities.Assessment.list('-created_date', 1),
        db.entities.Course.list(),
        db.entities.TestScore.list(),
        db.entities.Activity.list(),
        db.entities.Award.list(),
        db.entities.Essay.list(),
        db.entities.Interest.list(),
        db.entities.College.list(),
      ]);
      setAssessment(assessments[0] || null);
      setCounts({
        courses: courses.length,
        tests: tests.length,
        activities: activities.length,
        awards: awards.length,
        essays: essays.length,
        interests: interests.length,
        colleges: colleges.length,
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const analyze = async () => {
    setAnalyzing(true);
    try {
      const res = await db.functions.invoke('analyzeProfile', {});
      if (res.data && res.data.assessment) {
        setAssessment(res.data.assessment);
        await load();
        toast({ title: 'Profile analyzed', description: 'Your priorities and college ratings are updated.' });
      } else {
        throw new Error(res.data?.error || 'No result');
      }
    } catch (e) {
      toast({ variant: 'destructive', title: 'Analysis failed', description: e.message });
    } finally {
      setAnalyzing(false);
    }
  };

  const tier = assessment ? tierStyle(assessment.standing_tier) : null;
  const totalItems = Object.values(counts).reduce((a, b) => a + (b || 0), 0);

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8 sm:py-10">
      <PageHeader
        eyebrow="Dashboard"
        icon={Sparkles}
        title="Your application profile"
        description="An honest, evolving read of where you stand and what to do next."
        action={
          <Button onClick={analyze} disabled={analyzing || totalItems === 0} size="lg" className="w-full sm:w-auto bg-indigo-600 hover:bg-indigo-700">
            {analyzing ? <><RefreshCw className="w-4 h-4 mr-2 animate-spin" />Analyzing…</> : <><Sparkles className="w-4 h-4 mr-2" />Analyze my profile</>}
          </Button>
        }
      />

      {loading ? (
        <div className="h-64 flex items-center justify-center"><RefreshCw className="w-6 h-6 animate-spin text-muted-foreground" /></div>
      ) : !assessment ? (
        <div className="rounded-2xl border border-dashed bg-muted/30 p-6 sm:p-10">
          <div className="text-center max-w-md mx-auto">
            <div className="w-12 h-12 rounded-xl bg-indigo-100 text-indigo-600 flex items-center justify-center mx-auto"><Sparkles className="w-6 h-6" /></div>
            <h2 className="font-heading text-xl font-semibold mt-3">No analysis yet</h2>
            <p className="text-muted-foreground mt-1">Three steps to your personalized roadmap:</p>
          </div>
          <div className="mt-6 grid sm:grid-cols-3 gap-4 max-w-3xl mx-auto">
            {STEPS.map((step) => (
              <div key={step.n} className="rounded-xl border bg-background p-4">
                <div className="w-7 h-7 rounded-full bg-indigo-600 text-white flex items-center justify-center font-heading font-semibold text-sm">{step.n}</div>
                <div className="font-medium mt-3">{step.title}</div>
                <p className="text-sm text-muted-foreground mt-1">{step.detail}</p>
                <Link to={step.to} className="inline-flex items-center gap-1 mt-3 text-sm text-indigo-700 font-medium hover:underline">{step.cta} <ChevronRight className="w-3.5 h-3.5" /></Link>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div className="space-y-4 sm:space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <SectionCard
              className="lg:col-span-2"
              icon={TrendingUp}
              title="Current standing"
              description="How competitive your overall profile is right now."
              action={assessment.created_date ? <span className="text-xs text-muted-foreground whitespace-nowrap">Updated {moment(assessment.created_date).format('MMM D, YYYY')}</span> : null}
            >
              <div className="flex items-center gap-3">
                <span className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-sm font-medium ${tier.badge}`}>
                  <span className={`w-2 h-2 rounded-full ${tier.dot}`} />
                  {assessment.standing_tier}
                </span>
              </div>
              <p className="mt-4 text-foreground/90 leading-relaxed">{assessment.standing_summary}</p>
              <p className="text-sm text-muted-foreground mt-3">{tier.desc}</p>
            </SectionCard>

            <SectionCard icon={Gauge} title="Profile strength" description="How complete your material is.">
              <div className="text-4xl font-heading font-semibold">{assessment.completeness_percent}%</div>
              <Progress value={assessment.completeness_percent} className="mt-3" />
              {assessment.missing_items && assessment.missing_items.length > 0 && (
                <ul className="mt-4 space-y-1 text-sm text-muted-foreground">
                  {assessment.missing_items.slice(0, 4).map((m, i) => <li key={i} className="flex gap-2"><span className="text-rose-400">•</span>{m}</li>)}
                </ul>
              )}
            </SectionCard>
          </div>

          <SectionCard icon={Target} title="This month's priorities" description="The highest-impact things to focus on now.">
            <div className="space-y-3">
              {(assessment.priorities || []).map((p) => (
                <div key={p.priority} className="flex gap-4">
                  <div className="shrink-0 w-8 h-8 rounded-full bg-indigo-600 text-white flex items-center justify-center font-heading font-semibold text-sm">{p.priority}</div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-medium">{p.title}</span>
                      {p.category && <Badge variant="outline" className="text-xs">{p.category}</Badge>}
                    </div>
                    <p className="text-sm text-muted-foreground mt-0.5">{p.detail}</p>
                  </div>
                </div>
              ))}
            </div>
          </SectionCard>

          {assessment.dont_bother && assessment.dont_bother.length > 0 && (
            <SectionCard icon={Ban} title="Don't bother" description="Lower-value efforts you can safely skip." className="bg-muted/30">
              <div className="space-y-2">
                {assessment.dont_bother.map((d, i) => (
                  <div key={i} className="flex gap-3">
                    <span className="text-slate-400">—</span>
                    <div>
                      <span className="font-medium text-foreground/80">{d.title}</span>
                      <p className="text-sm text-muted-foreground">{d.reason}</p>
                    </div>
                  </div>
                ))}
              </div>
            </SectionCard>
          )}

          <SectionCard
            icon={School}
            title="Profile snapshot"
            description="Quick counts across your application."
            action={<Link to="/colleges" className="text-sm text-indigo-700 hover:underline flex items-center gap-1">Colleges <ChevronRight className="w-4 h-4" /></Link>}
          >
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
              {SECTIONS.map((s) => {
                const Icon = s.icon;
                const n = counts[s.key] || 0;
                return (
                  <Link key={s.key} to={s.to} className="rounded-xl border p-3 hover:border-indigo-200 hover:bg-indigo-50/40 transition-colors">
                    <Icon className="w-4 h-4 text-muted-foreground" />
                    <div className="text-2xl font-heading font-semibold mt-1">{n}</div>
                    <div className="text-xs text-muted-foreground">{s.label}</div>
                  </Link>
                );
              })}
            </div>
          </SectionCard>
        </div>
      )}
    </div>
  );
}