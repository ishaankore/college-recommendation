import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import AcademicsTab from '@/components/profile/AcademicsTab';
import ActivitiesTab from '@/components/profile/ActivitiesTab';
import AwardsTab from '@/components/profile/AwardsTab';
import EssaysTab from '@/components/profile/EssaysTab';
import InterestsTab from '@/components/profile/InterestsTab';
import PageHeader from '@/components/PageHeader';
import ProfileCompleteness from '@/components/profile/ProfileCompleteness';
import { User } from 'lucide-react';

export default function ProfilePage() {
  const [tab, setTab] = useState('academics');
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-10">
      <PageHeader eyebrow="Profile" icon={User} title="Your profile" description="The raw material of your application. Everything here feeds your monthly guidance." />
      <ProfileCompleteness onJump={setTab} />
      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="flex w-full overflow-x-auto sm:grid sm:grid-cols-5 no-scrollbar">
          <TabsTrigger value="academics" className="shrink-0">Academics</TabsTrigger>
          <TabsTrigger value="activities" className="shrink-0">Activities</TabsTrigger>
          <TabsTrigger value="awards" className="shrink-0">Awards</TabsTrigger>
          <TabsTrigger value="essays" className="shrink-0">Essays</TabsTrigger>
          <TabsTrigger value="interests" className="shrink-0">Interests</TabsTrigger>
        </TabsList>
        <TabsContent value="academics" className="mt-6"><AcademicsTab /></TabsContent>
        <TabsContent value="activities" className="mt-6"><ActivitiesTab /></TabsContent>
        <TabsContent value="awards" className="mt-6"><AwardsTab /></TabsContent>
        <TabsContent value="essays" className="mt-6"><EssaysTab /></TabsContent>
        <TabsContent value="interests" className="mt-6"><InterestsTab /></TabsContent>
      </Tabs>
    </div>
  );
}